#include "arduino_secrets.h"

#include <SoftwareSerial.h>
#include <TinyGPS++.h>

//================ GSM =================
SoftwareSerial sim800(2, 3);   // RX, TX
String EMERGENCY_PHONE = "+916005283095";

//================ GPS =================
SoftwareSerial gpsSerial(8, 9); // RX, TX
TinyGPSPlus gps;

//================ IO =================
#define BUZZER 12
#define BUTTON 11
#define RED_LED 6
#define GREEN_LED 7

//================ ACCELEROMETER =================
#define xPin A1
#define yPin A2
#define zPin A3

int xPrev, yPrev, zPrev;
int sensitivity = 60;

//================ STATE =================
bool impactDetected = false;
unsigned long impactTime = 0;
const unsigned long ALERT_DELAY = 10000; // 10 seconds

String latitude = "";
String longitude = "";

//================================================
void setup() {
  Serial.begin(9600);
  sim800.begin(9600);
  gpsSerial.begin(9600);

  pinMode(BUZZER, OUTPUT);
  pinMode(BUTTON, INPUT_PULLUP);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);

  digitalWrite(BUZZER, LOW);
  digitalWrite(RED_LED, LOW);
  digitalWrite(GREEN_LED, HIGH);

  delay(3000);

  Serial.println("SYSTEM START");

  sim800.println("AT");
  delay(1000);
  sim800.println("AT+CMGF=1");
  delay(1000);

  xPrev = analogRead(xPin);
  yPrev = analogRead(yPin);
  zPrev = analogRead(zPin);

  Serial.println("System Ready");
  Serial.println("Waiting for impact");
}

//================================================
void loop() {

  checkImpact();

  // Cancel button
  if (impactDetected && digitalRead(BUTTON) == LOW) {
    delay(50);
    if (digitalRead(BUTTON) == LOW) {
      Serial.println("Alert Cancelled by Button");
      cancelAlert();
    }
  }

  // After delay
  if (impactDetected && millis() - impactTime >= ALERT_DELAY) {
    Serial.println("Delay completed");

    digitalWrite(BUZZER, LOW);

    Serial.println("Making Call");
    makeCall();

    Serial.println("Sending SMS");
    sendAlertSMSWithRetry();

    impactDetected = false;
    digitalWrite(RED_LED, LOW);
    digitalWrite(GREEN_LED, HIGH);

    Serial.println("Alert Process Completed");
    Serial.println("--------------------------------");
  }

  while (gpsSerial.available()) {
    gps.encode(gpsSerial.read());
  }
}

//================================================
void checkImpact() {
  int x = analogRead(xPin);
  int y = analogRead(yPin);
  int z = analogRead(zPin);

  int delta = abs(x - xPrev) + abs(y - yPrev) + abs(z - zPrev);

  xPrev = x;
  yPrev = y;
  zPrev = z;

  Serial.print("Accelerometer Delta: ");
  Serial.println(delta);

  if (delta > sensitivity && !impactDetected) {
    triggerImpact(delta);
  }
}

//================================================
void triggerImpact(int delta) {
  Serial.println("Impact Detected");
  Serial.print("Impact Strength: ");
  Serial.println(delta);

  impactDetected = true;
  impactTime = millis();

  digitalWrite(BUZZER, HIGH);
  digitalWrite(RED_LED, HIGH);
  digitalWrite(GREEN_LED, LOW);

  getGPS();
}

//================================================
void cancelAlert() {
  impactDetected = false;
  digitalWrite(BUZZER, LOW);
  digitalWrite(RED_LED, LOW);
  digitalWrite(GREEN_LED, HIGH);

  Serial.println("Alert Cancelled");
  Serial.println("--------------------------------");
}

//================================================
void getGPS() {
  Serial.println("Getting GPS Data");
  unsigned long start = millis();

  while (millis() - start < 30000) {
    while (gpsSerial.available()) {
      if (gps.encode(gpsSerial.read()) && gps.location.isValid()) {
        latitude = String(gps.location.lat(), 6);
        longitude = String(gps.location.lng(), 6);

        Serial.print("Latitude: ");
        Serial.println(latitude);
        Serial.print("Longitude: ");
        Serial.println(longitude);
        return;
      }
    }
  }

  latitude = "";
  longitude = "";
  Serial.println("GPS Not Fixed");
}

//================================================
void makeCall() {
  sim800.println("ATD" + EMERGENCY_PHONE + ";");
  delay(20000);
  sim800.println("ATH");
  Serial.println("Call Ended");
}

//================================================
void sendAlertSMSWithRetry() {
  for (int i = 1; i <= 3; i++) {
    Serial.print("SMS Attempt ");
    Serial.println(i);

    if (sendSMS()) {
      Serial.println("SMS Sent Successfully");
      return;
    }
    delay(5000);
  }
  Serial.println("SMS Failed After 3 Attempts");
}

//================================================
bool sendSMS() {
  String sms = "ACCIDENT ALERT\nImmediate assistance required.\n\nLocation:\n";
  sms += "http://maps.google.com/maps?q=loc:";
  sms += latitude + "," + longitude;
  sms += "\n\nDelay: 10 seconds\nStatus: Auto Generated";

  Serial.println("SMS Content:");
  Serial.println(sms);
  Serial.println("----------------------------");

  sim800.println("AT+CMGF=1");
  delay(1000);
  sim800.println("AT+CMGS=\"" + EMERGENCY_PHONE + "\"");
  delay(1000);
  sim800.print(sms);
  sim800.write(26);
  delay(5000);

  return true;
}